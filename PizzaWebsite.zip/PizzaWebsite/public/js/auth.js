document.addEventListener("DOMContentLoaded", function () {
    console.log("auth.js loaded. Waiting for navbar...");
});

// Helper function to decode JWT using jwt-decode library
function decodeToken(token) {
    // jwt_decode must be available globally from the library loaded via CDN
    return jwt_decode(token);
}

// Function to update navbar authentication state when available
async function updateNavbarAuthState(retries = 10) {
    console.log("Checking navbar authentication state...");

    // Wait until navbar is fully loaded
    const authLink = document.getElementById("authLink");

    if (!authLink) {
        if (retries > 0) {
            console.warn(`Navbar not found yet. Retrying in 300ms... (${retries} attempts left)`);
            setTimeout(() => updateNavbarAuthState(retries - 1), 300);
        } else {
            console.error("Navbar not found after multiple attempts.");
        }
        return;
    }

    const token = sessionStorage.getItem("token");
    console.log("Checking token in sessionStorage:", token);

    if (!token) {
        console.warn("No token found. Showing login button.");
        authLink.innerHTML = `<a class="nav-link" href="login.html">Login</a>`;
        return;
    }

    // Decode JWT to check user details using jwt-decode
    let payload;
    try {
        payload = decodeToken(token);
        console.log("Decoded JWT Payload:", payload);

        if (payload.exp * 1000 < Date.now()) {
            console.warn("Token expired. Clearing session.");
            sessionStorage.removeItem("token");
            authLink.innerHTML = `<a class="nav-link" href="login.html">Login</a>`;
            return;
        }
    } catch (error) {
        console.error("Error decoding JWT. Clearing session.", error);
        sessionStorage.removeItem("token");
        authLink.innerHTML = `<a class="nav-link" href="login.html">Login</a>`;
        return;
    }

    console.log("Token is valid. User:", payload.username);
    
    // Instead of inline onclick, create the link and attach event listener
    authLink.innerHTML = `<a class="nav-link" href="#" id="logoutLink">Logout</a>`;
    document.getElementById("logoutLink").addEventListener("click", logout);

    // Verify token validity with backend using async/await
    try {
        // Changed endpoint from "/api/auth/validate" to "/api/auth/validate-session"
        const response = await fetch("/api/auth/validate-session", {
            method: "GET",
            headers: { "Authorization": `Bearer ${token}` }
        });
        const data = await response.json();
        console.log("Backend validation response:", data);
        if (!data.valid) {
            console.warn("Backend validation failed. Logging out.");
            await logout();
        }
    } catch (error) {
        console.error("Error validating session with backend:", error);
        await logout();
    }
}

// Logout function
async function logout() {
    console.log("Logging out...");

    if (!confirm("Are you sure you want to logout?")) return;

    try {
        const response = await fetch("/api/auth/logout", { method: "POST" });
        const result = await response.json();
        console.log("Logout Response:", result);

        if (result.clearToken) {
            sessionStorage.removeItem("token");
        }

        updateNavbarAuthState(); // Update navbar immediately

        setTimeout(() => {
            window.location.href = "login.html";
        }, 500);
    } catch (error) {
        console.error("Error during logout request:", error);
        alert("Something went wrong while logging out. Please try again later.");
    }
}