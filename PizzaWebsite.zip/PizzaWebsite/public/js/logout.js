async function logout() {
    console.log("🔹 Logging out...");

    if (!confirm("Are you sure you want to logout?")) return;

    try {
        const response = await fetch("/api/auth/logout", { method: "POST" });

        const result = await response.json();
        console.log(" Logout Response:", result);

        //  Clear token if instructed by backend
        if (result.clearToken) {
            sessionStorage.removeItem("token");
        }

        //  Update navbar immediately
        updateNavbarAuthState();

        //  Redirect user to login page
        setTimeout(() => {
            window.location.href = "login.html";
        }, 500);
    } catch (error) {
        console.error(" Error during logout request:", error);
        alert("Something went wrong while logging out.");
    }
}
