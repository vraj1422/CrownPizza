document.addEventListener("DOMContentLoaded", function () {
  // Attach click event listeners for password toggles
  const eyeIcon = document.getElementById("eyeIcon");
  const eyeIconConfirm = document.getElementById("eyeIconConfirm");

  if (eyeIcon) {
    // Find the parent element that should act as a button
    eyeIcon.parentElement.addEventListener("click", togglePasswordVisibility);
  }
  if (eyeIconConfirm) {
    eyeIconConfirm.parentElement.addEventListener("click", toggleConfirmPasswordVisibility);
  }

  // Attach form submission listener
  document.getElementById("registerForm").addEventListener("submit", async function (event) {
    event.preventDefault();
    console.log("🔹 Register form submitted.");

    // Retrieve and validate form inputs
    const usernameInput = document.getElementById("Username");
    const emailInput = document.getElementById("Email");
    const passwordInput = document.getElementById("password");
    const confirmPasswordInput = document.getElementById("confirmPassword");

    const username = usernameInput.value.trim();
    const email = emailInput.value.trim().toLowerCase();
    const password = passwordInput.value;
    const confirmPassword = confirmPasswordInput.value;

    // Validate required fields
    if (!username || !email || !password || !confirmPassword) {
      displayError("Please fill in all fields.");
      return;
    }

    // Validate password match
    if (password !== confirmPassword) {
      displayError("Passwords do not match!");
      return;
    }

    // Validate email format (optional)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      displayError("Please enter a valid email address.");
      return;
    }

    console.log("📨 Sending registration request...");

    // Disable the submit button to prevent duplicate submissions
    const submitButton = event.target.querySelector("button[type='submit']");
    submitButton.disabled = true;

    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, email, password })
      });

      const result = await response.json();
      console.log("✅ Server Response:", result);

      if (response.ok) {
        alert("🎉 Registration successful! You can now log in.");
        window.location.href = "/login.html";
      } else {
        console.error("Registration failed:", result.msg);
        displayError(result.msg);
      }
    } catch (error) {
      console.error("Error during registration request:", error);
      displayError("Something went wrong! Please try again.");
    } finally {
      submitButton.disabled = false;
    }
  });
});

// Helper function to display error messages on the page
function displayError(message) {
  let errorDiv = document.getElementById("registerError");
  if (!errorDiv) {
    errorDiv = document.createElement("div");
    errorDiv.id = "registerError";
    errorDiv.className = "alert alert-danger mt-3";
    document.getElementById("registerForm").appendChild(errorDiv);
  }
  errorDiv.textContent = message;
}

// Toggle password visibility for the main password input
function togglePasswordVisibility() {
  const passwordInput = document.getElementById("password");
  const eyeIcon = document.getElementById("eyeIcon");
  if (passwordInput.type === "password") {
    passwordInput.type = "text";
    eyeIcon.classList.replace("fa-eye", "fa-eye-slash");
  } else {
    passwordInput.type = "password";
    eyeIcon.classList.replace("fa-eye-slash", "fa-eye");
  }
}

// Toggle password visibility for the confirm password input
function toggleConfirmPasswordVisibility() {
  const confirmPasswordInput = document.getElementById("confirmPassword");
  const eyeIconConfirm = document.getElementById("eyeIconConfirm");
  if (confirmPasswordInput.type === "password") {
    confirmPasswordInput.type = "text";
    eyeIconConfirm.classList.replace("fa-eye", "fa-eye-slash");
  } else {
    confirmPasswordInput.type = "password";
    eyeIconConfirm.classList.replace("fa-eye-slash", "fa-eye");
  }
}