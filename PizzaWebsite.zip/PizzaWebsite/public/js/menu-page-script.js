// Wait until the DOM is fully loaded
document.addEventListener("DOMContentLoaded", function () {
  console.log("Menu page script loaded. Fetching products...");
  loadProducts();
});

/**
 * loadProducts()
 * Sends a GET request to the products API endpoint,
 * then groups products by category and renders the initial multi-category view.
 */
async function loadProducts() {
  try {
    const response = await fetch("/api/products");
    const result = await response.json();
    console.log("Fetched products:", result);

    if (result.success) {
      const groupedProducts = groupProductsByCategory(result.data);
      displayCategoriesView(groupedProducts);
    } else {
      document.getElementById("productContainer").innerHTML =
        `<p class="text-center text-danger">Error loading products: ${result.msg}</p>`;
    }
  } catch (error) {
    console.error("Error fetching products:", error);
    document.getElementById("productContainer").innerHTML =
      `<p class="text-center text-danger">Server error. Please try again later.</p>`;
  }
}

/**
 * groupProductsByCategory(products)
 * Groups an array of product objects by their category.
 * @param {Array} products - The product objects.
 * @returns {Object} An object where keys are categories and values are arrays of products.
 */
function groupProductsByCategory(products) {
  return products.reduce((groups, product) => {
    if (!groups[product.category]) {
      groups[product.category] = [];
    }
    groups[product.category].push(product);
    return groups;
  }, {});
}

/**
 * displayCategoriesView(groupedProducts)
 * Renders the initial view with each category's header and a horizontally scrollable row of product cards.
 * @param {Object} groupedProducts - Products grouped by category.
 */
function displayCategoriesView(groupedProducts) {
  const container = document.getElementById("productContainer");
  container.innerHTML = ""; // Clear container

  // Loop over each category and render its section
  for (const category in groupedProducts) {
    // Create section container
    const section = document.createElement("div");
    section.className = "category-section mb-4";

    // Create category header with a right-arrow button for filtering
    const header = document.createElement("div");
    header.className = "d-flex justify-content-between align-items-center mb-2";

    const title = document.createElement("h2");
    title.textContent = category;
    header.appendChild(title);

    const arrowBtn = document.createElement("button");
    arrowBtn.className = "btn btn-link";
    arrowBtn.innerHTML = "&#9654;"; // right arrow character
    arrowBtn.addEventListener("click", function () {
      displayFilteredCategory(category, groupedProducts[category]);
    });
    header.appendChild(arrowBtn);

    section.appendChild(header);

    // Create a horizontally scrollable container for product cards
    const scrollContainer = document.createElement("div");
    scrollContainer.className = "d-flex overflow-auto";

    groupedProducts[category].forEach(product => {
      const cardHtml = `
        <div class="card m-2" style="min-width: 250px;">
          <img src="${product.image}" class="card-img-top product-image" alt="${product.name}">
          <div class="card-body text-center">
            <h5 class="card-title product-name">${product.name}</h5>
            <p class="card-text product-description">${product.description || ""}</p>
            <p class="card-text product-price">$${parseFloat(product.price).toFixed(2)}</p>
            <div class="mb-2">
              <label for="qty-${product.id}" class="form-label">Quantity:</label>
              <input type="number" class="form-control" id="qty-${product.id}" value="1" min="1" style="width: 80px; display: inline-block;">
            </div>
            <button type="button" class="btn btn-primary" onclick="addToCart(${product.id}, '${product.name}', '${product.price}', 'qty-${product.id}', '${product.image}')">
              Add To Cart
            </button>
          </div>
        </div>
      `;
      // Convert string to DOM element and append
      const tempDiv = document.createElement("div");
      tempDiv.innerHTML = cardHtml;
      scrollContainer.appendChild(tempDiv.firstElementChild);
    });

    section.appendChild(scrollContainer);
    container.appendChild(section);
  }
}

/**
 * displayFilteredCategory(category, products)
 * Renders a filtered view showing only products from the selected category,
 * along with a Back button to return to the initial multi-category view.
 * @param {string} category - The selected category.
 * @param {Array} products - Array of product objects in that category.
 */
function displayFilteredCategory(category, products) {
  const container = document.getElementById("productContainer");
  container.innerHTML = ""; // Clear container

  // Create Back button
  const backBtn = document.createElement("button");
  backBtn.className = "btn btn-secondary mb-3";
  backBtn.textContent = "Back";
  backBtn.addEventListener("click", function () {
    // Reload all products view (re-fetch or cache could be used)
    loadProducts();
  });
  container.appendChild(backBtn);

  // Create header for selected category
  const header = document.createElement("h2");
  header.className = "text-center mb-4";
  header.textContent = category;
  container.appendChild(header);

  // Create horizontally scrollable container for filtered products
  const scrollContainer = document.createElement("div");
  scrollContainer.className = "d-flex overflow-auto";

  products.forEach(product => {
    const cardHtml = `
      <div class="card m-2" style="min-width: 250px;">
        <img src="${product.image}" class="card-img-top product-image" alt="${product.name}">
        <div class="card-body text-center">
          <h5 class="card-title product-name">${product.name}</h5>
          <p class="card-text product-description">${product.description || ""}</p>
          <p class="card-text product-price">$${parseFloat(product.price).toFixed(2)}</p>
          <div class="mb-2">
            <label for="qty-${product.id}" class="form-label">Quantity:</label>
            <input type="number" class="form-control" id="qty-${product.id}" value="1" min="1" style="width: 80px; display: inline-block;">
          </div>
          <button type="button" class="btn btn-primary" onclick="addToCart(${product.id}, '${product.name}', '${product.price}', 'qty-${product.id}', '${product.image}')">
            Add To Cart
          </button>
        </div>
      </div>
    `;
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = cardHtml;
    scrollContainer.appendChild(tempDiv.firstElementChild);
  });

  container.appendChild(scrollContainer);
}

/**
 * addToCart()
 * Adds a product to the cart stored in localStorage.
 * @param {int} id - The product ID.
 * @param {string} name - The product name.
 * @param {string} price - The product price.
 * @param {string} quantityId - The ID of the quantity input element.
 * @param {string} image - The product image URL.
 */
function addToCart(id, name, price, quantityId, image) {
  const quantity = quantityId ? parseInt(document.getElementById(quantityId).value, 10) : 1;
  const unitPrice = parseFloat(price);

  // Create an item object for the cart using id
  const item = {
    id: id,
    name: name,
    price: unitPrice,
    quantity: quantity,
    image: image
  };

  // Retrieve the current cart from localStorage (or initialize an empty array)
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  // Check if the item (by id) is already in the cart
  const existingIndex = cart.findIndex(cartItem => cartItem.id === id);

  if (existingIndex > -1) {
    cart[existingIndex].quantity += quantity;
  } else {
    cart.push(item);
  }

  // Save the updated cart back to localStorage
  localStorage.setItem("cart", JSON.stringify(cart));

  console.log("Cart updated:", cart);
}