function loadComponent(id, file, callback) {
    fetch(file)
        .then(response => {
            if (!response.ok) throw new Error(`Failed to load ${file}`);
            return response.text();
        })
        .then(data => {
            document.getElementById(id).innerHTML = data;
            console.log(` ${file} loaded.`);

            if (callback) callback();
        })
        .catch(error => console.error(` Error loading ${file}:`, error));
}

//  Load navbar first, then footer
document.addEventListener("DOMContentLoaded", function () {
    console.log("🔹 Initializing page...");

    //  Load navbar first
    loadComponent("navbar-container", "partials/navbar.html", function () {
        console.log(" Navbar loaded. Now loading `auth.js`...");

        //  Load `auth.js` dynamically
        const script = document.createElement("script");
        script.src = "js/auth.js";
        script.defer = true;
        script.onload = function () {
            console.log(" auth.js loaded. Now running `updateNavbarAuthState()`...");
            setTimeout(updateNavbarAuthState, 200); // Ensure navbar is updated after auth.js loads
        };
        document.body.appendChild(script);
    });

    //  Load footer
    loadComponent("footer-container", "partials/footer.html");
});
