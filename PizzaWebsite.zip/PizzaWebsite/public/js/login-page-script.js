document.addEventListener("DOMContentLoaded", function () {
    // Attach event listener for toggling password visibility
    const togglePassword = document.getElementById("togglePassword");
    if (togglePassword) {
        togglePassword.addEventListener("click", togglePasswordVisibility);
    }

    // Attach event listener for the Register button
    const registerButton = document.getElementById("registerButton");
    if (registerButton) {
        registerButton.addEventListener("click", function () {
            window.location.href = 'register.html';
        });
    }

    // Attach login form submit handler
    document.getElementById("loginForm").addEventListener("submit", async function(event) {
        event.preventDefault();
        console.log("🔹 Login form submitted.");

        // Retrieve and validate form inputs
        const emailInput = document.getElementById("Email");
        const passwordInput = document.getElementById("password");
        const email = emailInput.value.trim().toLowerCase();
        const password = passwordInput.value;

        if (!email || !password) {
            console.error("❌ Email and password are required.");
            displayError("Both email and password are required.");
            return;
        }

        // Optionally, add more client-side validation (e.g., regex for email format)
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            console.error("❌ Invalid email format.");
            displayError("Please enter a valid email address.");
            return;
        }

        console.log("📨 Sending login request...");

        // Disable the submit button to prevent multiple submissions
        const submitButton = event.target.querySelector("button[type='submit']");
        submitButton.disabled = true;

        try {
            const response = await fetch("/api/auth/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ email, password })
            });

            const result = await response.json();
            console.log("✅ Server Response:", result);

            if (response.ok) {
                console.log("🔐 Login successful! Token received.");
                sessionStorage.setItem("token", result.token);

                console.log("🔄 Updating navbar state...");
                setTimeout(updateNavbarAuthState, 500);

                // Redirect to index.html after a short delay
                setTimeout(() => {
                    window.location.href = "/index.html";
                }, 1000);
            } else {
                console.error("❌ Login failed:", result.msg);
                displayError(result.msg);
            }
        } catch (error) {
            console.error("💥 Error during login request:", error);
            displayError("Something went wrong! Please try again.");
        } finally {
            // Re-enable the submit button after the request completes
            submitButton.disabled = false;
        }
    });
});

// Function to toggle password visibility
function togglePasswordVisibility() {
    const passwordInput = document.getElementById("password");
    const eyeIcon = document.getElementById("eyeIcon");
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        eyeIcon.classList.replace("fa-eye", "fa-eye-slash");
    } else {
        passwordInput.type = "password";
        eyeIcon.classList.replace("fa-eye-slash", "fa-eye");
    }
}

// Function to display error messages on the page
function displayError(message) {
    let errorDiv = document.getElementById("loginError");
    if (!errorDiv) {
        errorDiv = document.createElement("div");
        errorDiv.id = "loginError";
        errorDiv.className = "alert alert-danger mt-3";
        document.getElementById("loginForm").appendChild(errorDiv);
    }
    errorDiv.textContent = message;
}