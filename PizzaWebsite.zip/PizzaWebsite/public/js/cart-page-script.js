// Cart-Page-Script.js

// Run when the DOM is fully loaded
document.addEventListener("DOMContentLoaded", function() {
    displayCartItems();
    setupCheckout();
  });
  
  /**
   * Retrieve cart items from localStorage.
   * @returns {Array} Array of cart item objects.
   */
  function getCartItems() {
    return JSON.parse(localStorage.getItem("cart")) || [];
  }
  
  /**
   * Save the provided cart items array back to localStorage.
   * @param {Array} items - Array of cart item objects.
   */
  function saveCartItems(items) {
    localStorage.setItem("cart", JSON.stringify(items));
  }
  
  /**
   * Display cart items and update the total amount.
   */
  function displayCartItems() {
    const cartItems = getCartItems();
    const cartItemsElement = document.getElementById("cartItems");
    const totalAmountElement = document.getElementById("totalAmount");
  
    // Clear any existing content
    cartItemsElement.innerHTML = "";
  
    // Initialize total amount
    let totalAmount = 0;
  
    // If no items, show a message
    if (cartItems.length === 0) {
      cartItemsElement.innerHTML = `<p class="text-center">Your cart is empty.</p>`;
      totalAmountElement.textContent = `Total: $0.00`;
      return;
    }
  
    // Create a row container for the product cards
    const row = document.createElement("div");
    row.className = "row";
  
    // Loop over each cart item
    cartItems.forEach(item => {
      // Create column container
      const col = document.createElement("div");
      col.className = "col-sm-4 themed-grid-col mb-4";
  
      // Create card
      const card = document.createElement("div");
      card.className = "card h-100";
  
      // Create card body
      const cardBody = document.createElement("div");
      cardBody.className = "card-body position-relative text-center";
  
      // Create a price badge (positioned at top-left)
      const priceLabelDiv = document.createElement("div");
      priceLabelDiv.className = "position-absolute top-0 start-0";
      const priceSpan = document.createElement("span");
      priceSpan.className = "badge priceLabel";
      priceSpan.textContent = `$${item.price.toFixed(2)}`;
      priceLabelDiv.appendChild(priceSpan);
      cardBody.appendChild(priceLabelDiv);
  
      // Create remove button (positioned at top-right)
      const removeButton = document.createElement("button");
      removeButton.textContent = "Remove";
      removeButton.className = "btn btn-danger remove-btn position-absolute top-0 end-0";
      // Now using product id instead of name
      removeButton.addEventListener("click", function() {
        removeCartItem(item.id);
      });
      cardBody.appendChild(removeButton);
  
      // Product image
      const imageEl = document.createElement("img");
      imageEl.src = item.image;
      imageEl.alt = item.name;
      imageEl.className = "card-img-top mt-5";
      cardBody.appendChild(imageEl);
  
      // Product name
      const nameEl = document.createElement("h5");
      nameEl.textContent = item.name;
      cardBody.appendChild(nameEl);
  
      // Display quantity
      const quantityEl = document.createElement("p");
      quantityEl.textContent = `Quantity: ${item.quantity}`;
      cardBody.appendChild(quantityEl);
  
      // If you have size (optional), you can add that here.
      if(item.size) {
        const sizeEl = document.createElement("p");
        sizeEl.textContent = `Size: ${item.size}`;
        cardBody.appendChild(sizeEl);
      }
  
      // Append card body to card, and card to column
      card.appendChild(cardBody);
      col.appendChild(card);
      row.appendChild(col);
  
      // Update total amount
      totalAmount += item.price * item.quantity;
    });
  
    // Append row to the cart items container
    cartItemsElement.appendChild(row);
    totalAmountElement.textContent = `Total: $${totalAmount.toFixed(2)}`;
  }
  
  /**
   * Remove a cart item by product id.
   * @param {number|string} id - The product id to remove.
   */
  function removeCartItem(id) {
    let cartItems = getCartItems();
    // Find the index of the item with matching id
    const index = cartItems.findIndex(item => item.id === id);
    if (index !== -1) {
      // Remove the item from the cart array
      cartItems.splice(index, 1);
      // Save the updated cart and refresh the display
      saveCartItems(cartItems);
      displayCartItems();
    }
  }
  
  /**
   * Set up the checkout button to redirect to the payment page.
   */
  function setupCheckout() {
    const checkoutButton = document.getElementById("checkoutButton");
    if (checkoutButton) {
      checkoutButton.addEventListener("click", function() {
        window.location.href = "Payment-Page.html";
      });
    }
  }
  