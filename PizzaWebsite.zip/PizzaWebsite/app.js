const express = require("express");
const session = require("express-session");
const MySQLStore = require("express-mysql-session")(session); // Store sessions in DB
const cors = require("cors");
const dotenv = require("dotenv");
const helmet = require("helmet"); // Security headers middleware
const authRoutes = require("./src/routes/authRoutes");
const db = require("./src/config/db");

dotenv.config();

const app = express();

// Logging the initialization of the app
console.log("🔹 Initializing Express App...");

// Security Middleware: Set various HTTP headers for security
// Disable Helmet's default Content Security Policy header
app.use(helmet({ contentSecurityPolicy: false }));
console.log(" Middleware: Helmet security headers enabled (CSP disabled).");

// Custom middleware to remove any CSP header that might still be set
app.use((req, res, next) => {
  res.removeHeader("Content-Security-Policy");
  next();
});
console.log(" Middleware: Removed Content-Security-Policy header if present.");

// Middleware for parsing JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
console.log(" Middleware: JSON and URL-encoded parsing enabled.");

// CORS (Enable Frontend Communication)
app.use(cors({
    origin: "http://localhost:3000",
    credentials: true,  // Allow credentials
    allowedHeaders: ["Content-Type", "Authorization"]
}));
console.log(" Middleware: CORS enabled for http://localhost:3000");

// Serving Static Files
app.use(express.static("public"));
console.log(" Middleware: Serving static files from 'public' directory.");

// MySQL Session Store
const sessionStore = new MySQLStore({}, db);

// Session Configuration
app.use(session({
    secret: process.env.SESSION_SECRET || "mysecret",
    resave: false,
    saveUninitialized: false,
    store: sessionStore,  // Store sessions in MySQL
    cookie: { secure: false, httpOnly: true, maxAge: 1000 * 60 * 60 } // For production, set secure:true and use HTTPS
}));
console.log(" Middleware: Session initialized with MySQL storage.");

// Route Registration
console.log(" Registering API Routes...");
app.use("/api/auth", authRoutes);
console.log(" Route: '/api/auth' registered.");

const productRoutes = require("./src/routes/productRoutes");
app.use("/api/products", productRoutes);

// Health Check Route
app.get("/", (req, res) => {
    console.log(" GET / request received.");
    res.send("Server is running!");
});

// Redirect `/homepage.html` to `/index.html`
app.get("/homepage.html", (req, res) => {
    res.redirect("/index.html");
});

// Error Handling Middleware for Unknown Endpoints (404)
app.use((req, res, next) => {
    res.status(404).json({ success: false, msg: "Endpoint not found" });
});

// Global Error Handler Middleware
app.use((err, req, res, next) => {
    console.error("Unhandled error:", err);
    res.status(500).json({ success: false, msg: "Internal server error" });
});

// Start Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));