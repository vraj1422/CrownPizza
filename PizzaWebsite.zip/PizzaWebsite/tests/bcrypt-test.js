const bcrypt = require("bcryptjs");
const db = require("../src/config/db"); // Import MySQL connection

async function testBcrypt() {
    const enteredPassword = "password123";

    console.log(" Testing bcrypt comparison...");
    console.log(" Entered Password:", enteredPassword);

    try {
        // Hash the entered password (to check if it matches stored hash)
        const enteredPasswordHashed = await bcrypt.hash(enteredPassword, 10);
        console.log(" Hashed Version of Entered Password:", enteredPasswordHashed);

        // Fetch stored hash from database for testuser
        const [rows] = await db.query("SELECT password FROM users WHERE username = ?", ["testuser"]);
        
        if (rows.length === 0) {
            console.warn(" User 'testuser' not found in database!");
            return;
        }

        const storedHash = rows[0].password; // Extract hash from database

        console.log(" Stored Hash (from database):", storedHash);

        // Compare entered password with stored hash
        const isMatch = await bcrypt.compare(enteredPassword, storedHash);

        console.log(" Password Match Result:", isMatch ? " Matched" : " Not Matched");

        if (!isMatch) {
            console.warn(" WARNING: Either the stored hash is incorrect or the password is wrong.");
            console.warn(" POSSIBLE SOLUTION: The stored hash should match the hashed version of the entered password.");
        }
    } catch (error) {
        console.error(" Error during bcrypt comparison:", error.message);
    } finally {
        process.exit(); // Exit script after test
    }
}

// Run the test
testBcrypt();
