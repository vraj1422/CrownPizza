const bcrypt = require("bcryptjs");

async function generateNewHash() {
    const password = "password123"; // Ensure this is the correct password
    const hashedPassword = await bcrypt.hash(password, 10);
    console.log("🔑 New Hashed Password:", hashedPassword);
}

generateNewHash();
