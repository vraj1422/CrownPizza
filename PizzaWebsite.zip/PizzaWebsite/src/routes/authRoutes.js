// authRoutes.js
const express = require("express");
const router = express.Router();
const rateLimit = require("express-rate-limit");
const authController = require("../controllers/authController");

// Rate limiter for login route: maximum 10 requests per 15 minutes per IP
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 10,
    message: { success: false, msg: "Too many login attempts. Please try again later." }
});

// Rate limiter for registration route: maximum 5 requests per 15 minutes per IP
const registerLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 5,
    message: { success: false, msg: "Too many registration attempts. Please try again later." }
});

// Login route with rate limiting
router.post("/login", loginLimiter, authController.validateLogin, authController.login);

// Registration route with rate limiting
router.post("/register", registerLimiter, authController.validateRegistration, authController.register);

// Validate session route
router.get("/validate-session", authController.validateSession);

// Logout route
router.post("/logout", authController.logout);

module.exports = router;
