const express = require("express");
const router = express.Router();
const productController = require("../controllers/productController");
const { body } = require("express-validator");

/**
 * GET /api/products
 * Retrieve all products.
 */
router.get("/", productController.getAllProducts);

/**
 * GET /api/products/:id
 * Retrieve a single product by its ID.
 */
router.get("/:id", productController.getProductById);

/**
 * POST /api/products
 * Create a new product.
 * Expected payload: { name, description, price, image, category }
 */
router.post(
  "/",
  // Optional: Validation middleware can be added here.
  [
    body("name").trim().notEmpty().withMessage("Name is required"),
    body("price").notEmpty().withMessage("Price is required"),
    // You can add more validations as needed.
  ],
  productController.createProduct
);

/**
 * PUT /api/products/:id
 * Update an existing product.
 * Expected payload: { name?, description?, price?, image?, category? }
 */
router.put(
  "/:id",
  // Optional: Validation middleware for update.
  [
    body("name").optional().trim().notEmpty().withMessage("Name cannot be empty"),
    body("price").optional().notEmpty().withMessage("Price cannot be empty"),
  ],
  productController.updateProduct
);

/**
 * DELETE /api/products/:id
 * Delete a product by its ID.
 */
router.delete("/:id", productController.deleteProduct);

module.exports = router;
