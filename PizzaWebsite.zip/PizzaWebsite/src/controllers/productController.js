// src/controllers/productController.js
const Product = require("../models/Product");
const { body, validationResult } = require("express-validator");
const winston = require("winston");

// Create a Winston logger instance
const logger = winston.createLogger({
  level: "info",
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [new winston.transports.Console()]
});

/**
 * Get all products.
 * GET /api/products
 */
exports.getAllProducts = async (req, res, next) => {
  try {
    logger.info("Fetching all products...");
    const result = await Product.getAllProducts();
    if (result.success) {
      return res.json({ success: true, data: result.data });
    } else {
      return res.status(500).json({ success: false, msg: "Failed to fetch products" });
    }
  } catch (error) {
    logger.error("Error fetching products:", error.message);
    return res.status(500).json({ success: false, msg: "Server error", error: error.message });
  }
};

/**
 * Get a product by ID.
 * GET /api/products/:id
 */
exports.getProductById = async (req, res, next) => {
  const productId = req.params.id;
  try {
    logger.info(`Fetching product with ID: ${productId}`);
    const result = await Product.getProductById(productId);
    if (result.success && result.data) {
      return res.json({ success: true, data: result.data });
    } else {
      return res.status(404).json({ success: false, msg: "Product not found" });
    }
  } catch (error) {
    logger.error("Error fetching product by ID:", error.message);
    return res.status(500).json({ success: false, msg: "Server error", error: error.message });
  }
};

/**
 * Create a new product.
 * POST /api/products
 * Expected payload: { name, description, price, image, category }
 */
exports.createProduct = async (req, res, next) => {
  // Validate input fields if you add validation middleware on the route
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    logger.warn("Product creation validation failed", errors.array());
    return res.status(400).json({ success: false, msg: "Validation errors", errors: errors.array() });
  }

  try {
    const { name, description, price, image, category } = req.body;
    logger.info("Creating new product:", name);
    const result = await Product.createProduct({ name, description, price, image, category });
    if (result.success) {
      return res.status(201).json({ success: true, msg: "Product created successfully", data: result.data });
    } else {
      return res.status(500).json({ success: false, msg: "Failed to create product" });
    }
  } catch (error) {
    logger.error("Error creating product:", error.message);
    return res.status(500).json({ success: false, msg: "Server error", error: error.message });
  }
};

/**
 * Update an existing product.
 * PUT /api/products/:id
 * Expected payload: { name?, description?, price?, image?, category? }
 */
exports.updateProduct = async (req, res, next) => {
  const productId = req.params.id;
  // Validate input fields if needed
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    logger.warn("Product update validation failed", errors.array());
    return res.status(400).json({ success: false, msg: "Validation errors", errors: errors.array() });
  }

  try {
    const updateData = req.body;
    logger.info(`Updating product with ID: ${productId}`, updateData);
    const result = await Product.updateProduct(productId, updateData);
    if (result.success) {
      return res.json({ success: true, msg: "Product updated successfully", data: result.data });
    } else {
      return res.status(404).json({ success: false, msg: "Product update failed" });
    }
  } catch (error) {
    logger.error("Error updating product:", error.message);
    return res.status(500).json({ success: false, msg: "Server error", error: error.message });
  }
};

/**
 * Delete a product.
 * DELETE /api/products/:id
 */
exports.deleteProduct = async (req, res, next) => {
  const productId = req.params.id;
  try {
    logger.info(`Deleting product with ID: ${productId}`);
    const result = await Product.deleteProduct(productId);
    if (result.success) {
      return res.json({ success: true, msg: "Product deleted successfully", data: result.data });
    } else {
      return res.status(404).json({ success: false, msg: "Product deletion failed" });
    }
  } catch (error) {
    logger.error("Error deleting product:", error.message);
    return res.status(500).json({ success: false, msg: "Server error", error: error.message });
  }
};
