// authController.js
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { body, validationResult } = require("express-validator");
const User = require("../models/User");
const winston = require("winston");

// Create a Winston logger instance
const logger = winston.createLogger({
    level: "info",
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [new winston.transports.Console()]
});

/**
 * Centralized error handling helper
 * @param {Object} res - Express response object
 * @param {Error} error - Caught error
 * @param {String} customMsg - Custom error message to return
 */
function handleError(res, error, customMsg = "Server error") {
    logger.error(customMsg, error.message);
    return res.status(500).json({ success: false, msg: customMsg, error: error.message });
}

/**
 * Middleware for validating registration inputs using express-validator.
 * Attach this middleware before the register controller.
 */
exports.validateRegistration = [
    body("username").trim().notEmpty().withMessage("Username is required"),
    body("password").notEmpty().withMessage("Password is required"),
    body("email").isEmail().withMessage("A valid email is required")
];

/**
 * Register new user (always with role "customer")
 */
exports.register = async (req, res, next) => {
    // Validate request inputs
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        logger.warn("Registration validation failed", errors.array());
        return res.status(400).json({ success: false, msg: "Validation errors", errors: errors.array() });
    }

    try {
        const { username, password, email } = req.body;
        logger.info("Registration request received for:", username);

        // Force role to 'customer'
        const role = "customer";
        logger.info("Forcing role to 'customer' during registration.");

        // Check if user already exists by username (if you want uniqueness by username)
        const existingUserResponse = await User.findByUsername(username);
        if (existingUserResponse.success && existingUserResponse.data) {
            logger.warn("Username already exists:", username);
            return res.status(409).json({ success: false, msg: "Username already taken!" });
        }

        // Hash password
        logger.info("Hashing password...");
        const hashedPassword = await bcrypt.hash(password, 10);
        logger.info("Password hashed successfully.");

        // Create new user with role 'customer'
        logger.info("Creating new user in the database...", { username });
        const createResponse = await User.createUser(username, hashedPassword, email, role);
        if (!createResponse.success) {
            throw new Error("User creation failed.");
        }
        logger.info(`User registered: ${username} with role: ${role}`);

        res.status(201).json({ success: true, msg: "User registered successfully!" });
    } catch (error) {
        return handleError(res, error, "Server error during registration.");
    }
};

/**
 * Middleware for validating login inputs using express-validator.
 * Attach this middleware before the login controller.
 */
exports.validateLogin = [
    body("email").trim().notEmpty().withMessage("Email is required"),
    body("password").notEmpty().withMessage("Password is required")
];

/**
 * Login user with role-based redirection using email.
 */
exports.login = async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        logger.warn("Login validation failed", errors.array());
        return res.status(400).json({ success: false, msg: "Validation errors", errors: errors.array() });
    }

    try {
        logger.info("Login request received.");
        const { email, password } = req.body; // Now using email for login

        // Look up user by email (make sure User.findByEmail is implemented)
        logger.info("Looking up user in database...", { email });
        const userResponse = await User.findByEmail(email);
        if (!userResponse.success || !userResponse.data) {
            logger.warn("User not found:", email);
            return res.status(401).json({ success: false, msg: "Invalid email or password!" });
        }
        const user = userResponse.data;

        // Compare provided password with stored hash
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            logger.warn("Invalid password for:", email);
            return res.status(401).json({ success: false, msg: "Invalid email or password!" });
        }

        // Generate JWT token, set session, etc.
        const expiresIn = "1h";
        const token = jwt.sign(
            { userId: user.id, username: user.username, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn }
        );

        req.session.user = { id: user.id, username: user.username, role: user.role };
        logger.info("Login successful for:", { email });

        // Determine redirect path based on user role
        let redirectPath = user.role === "admin" ? "admin-dashboard" : "menu-page";

        res.json({ success: true, msg: "Login successful!", token, expiresIn, redirect: redirectPath });
    } catch (error) {
        return handleError(res, error, "Server error during login.");
    }
};

/**
 * Validate session using JWT
 */
exports.validateSession = (req, res, next) => {
    try {
        logger.info("Validating session...");
        const token = req.headers.authorization?.split(" ")[1];
        if (!token) {
            logger.warn("No token provided in headers.");
            return res.status(401).json({ success: false, valid: false, msg: "No token provided" });
        }

        jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
            if (err) {
                logger.error("JWT verification failed:", err.message);
                return res.status(403).json({ success: false, valid: false, msg: "Invalid token" });
            }
            logger.info("Token validated successfully for user:", decoded.username);
            res.json({ success: true, valid: true, user: decoded });
        });
    } catch (error) {
        return handleError(res, error, "Server error during session validation.");
    }
};

/**
 * Logout user
 */
exports.logout = (req, res, next) => {
    try {
        logger.info("Logging out user...");
        req.session.destroy((err) => {
            if (err) {
                logger.error("Error destroying session during logout:", err.message);
                return res.status(500).json({ success: false, msg: "Server error during logout." });
            }
            logger.info("Logout successful.");
            res.json({ success: true, msg: "Logout successful!", clearToken: true });
        });
    } catch (error) {
        return handleError(res, error, "Server error during logout.");
    }
};