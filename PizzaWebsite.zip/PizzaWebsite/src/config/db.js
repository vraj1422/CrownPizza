const mysql = require("mysql2");
require("dotenv").config();

console.log(" Initializing MySQL Database Connection...");

const db = mysql.createPool({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASS || "",
    database: process.env.DB_NAME || "pizza_db",
    connectionLimit: 10
}).promise();

// Test Database Connection
async function testDBConnection() {
    try {
        const [result] = await db.query("SELECT 1 + 1 AS test");
        console.log(" Database connection successful. Test Query Result:", result[0].test);
    } catch (error) {
        console.error(" Database connection failed:", error.message);
    }
}

testDBConnection();

module.exports = db;
