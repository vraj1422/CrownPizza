const db = require("../config/db");

class User {
    // Find user by username
    static async findByUsername(username) {
        console.log(`🔹 Searching for user: ${username}`);
        try {
            const [rows] = await db.query("SELECT * FROM users WHERE username = ?", [username]);
            if (!rows || rows.length === 0) {
                console.warn(`❌ User not found: ${username}`);
                return { success: false, message: "User not found", data: null };
            }
            console.log(`✅ User found: ${rows[0].username}`);
            return { success: true, message: "User found", data: rows[0] };
        } catch (error) {
            console.error("❌ Database query error:", error.message);
            return { success: false, message: "Database error while fetching user.", error };
        }
    }

    // Find user by email (used for login)
    static async findByEmail(email) {
        console.log(`🔍 Searching for user by email: ${email}`);
        try {
            const [rows] = await db.query("SELECT * FROM users WHERE email = ?", [email]);
            if (!rows || rows.length === 0) {
                console.warn(`❌ User not found with email: ${email}`);
                return { success: false, message: "User not found", data: null };
            }
            console.log(`✅ User found: ${rows[0].username} (${rows[0].email})`);
            return { success: true, message: "User found", data: rows[0] };
        } catch (error) {
            console.error("❌ Database query error:", error.message);
            return { success: false, message: "Database error while fetching user.", error };
        }
    }

    // Create new user
    static async createUser(username, passwordHash, email, role = 'customer') {
        try {
            const result = await db.query(
                "INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)",
                [username, passwordHash, email, role]
            );
            console.log(`✅ New user registered: ${username}`);
            return { success: true, message: "User created successfully", data: result };
        } catch (error) {
            console.error("❌ Error inserting user:", error.message);
            return { success: false, message: "Database error while inserting user.", error };
        }
    }

    // Retrieve all users
    static async getAllUsers() {
        try {
            const [rows] = await db.query("SELECT * FROM users");
            console.log(`✅ Retrieved all users, count: ${rows.length}`);
            return { success: true, message: "All users retrieved", data: rows };
        } catch (error) {
            console.error("❌ Error fetching all users:", error.message);
            return { success: false, message: "Database error while retrieving all users.", error };
        }
    }

    // Get users by role
    static async getUsersByRole(role) {
        try {
            const [rows] = await db.query("SELECT * FROM users WHERE role = ?", [role]);
            console.log(`✅ Retrieved users with role '${role}', count: ${rows.length}`);
            return { success: true, message: `Users with role '${role}' retrieved`, data: rows };
        } catch (error) {
            console.error("❌ Error fetching users by role:", error.message);
            return { success: false, message: "Database error while retrieving users by role.", error };
        }
    }

    // Update user by id
    static async updateUser(id, fields = {}) {
        try {
            // Build the dynamic SET clause from fields object
            let setClause = [];
            let values = [];
            for (let key in fields) {
                setClause.push(`${key} = ?`);
                values.push(fields[key]);
            }
            if (setClause.length === 0) {
                return { success: false, message: "No fields provided for update" };
            }
            values.push(id); // Append id for WHERE clause

            const query = `UPDATE users SET ${setClause.join(", ")} WHERE id = ?`;
            const result = await db.query(query, values);
            console.log(`✅ Updated user id: ${id}`);
            return { success: true, message: "User updated successfully", data: result };
        } catch (error) {
            console.error("❌ Error updating user:", error.message);
            return { success: false, message: "Database error while updating user.", error };
        }
    }

    // Delete user by id
    static async deleteUser(id) {
        try {
            const result = await db.query("DELETE FROM users WHERE id = ?", [id]);
            console.log(`✅ Deleted user id: ${id}`);
            return { success: true, message: "User deleted successfully", data: result };
        } catch (error) {
            console.error("❌ Error deleting user:", error.message);
            return { success: false, message: "Database error while deleting user.", error };
        }
    }
}

module.exports = User;
