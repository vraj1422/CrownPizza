const db = require("../config/db");

class Product {
  /**
   * Retrieve all products.
   * @returns {Promise<Object>} Object with success and data properties.
   */
  static async getAllProducts() {
    try {
      const [rows] = await db.query("SELECT * FROM products");
      return { success: true, data: rows };
    } catch (error) {
      console.error("Error fetching products:", error.message);
      return { success: false, message: "Database error while fetching products", error };
    }
  }

  /**
   * Retrieve a product by its ID.
   * @param {number} id - Product ID.
   * @returns {Promise<Object>} Object with success and data properties.
   */
  static async getProductById(id) {
    try {
      const [rows] = await db.query("SELECT * FROM products WHERE id = ?", [id]);
      if (!rows || rows.length === 0) {
        return { success: false, message: "Product not found", data: null };
      }
      return { success: true, data: rows[0] };
    } catch (error) {
      console.error("Error fetching product by ID:", error.message);
      return { success: false, message: "Database error while fetching product", error };
    }
  }

  /**
   * Retrieve products by name (partial match).
   * @param {string} name - Product name or partial name.
   * @returns {Promise<Object>} Object with success and data properties.
   */
  static async getProductsByName(name) {
    try {
      const [rows] = await db.query("SELECT * FROM products WHERE name LIKE ?", [`%${name}%`]);
      return { success: true, data: rows };
    } catch (error) {
      console.error("Error fetching products by name:", error.message);
      return { success: false, message: "Database error while fetching products by name", error };
    }
  }

  /**
   * Retrieve products by category.
   * @param {string} category - Product category.
   * @returns {Promise<Object>} Object with success and data properties.
   */
  static async getProductsByCategory(category) {
    try {
      const [rows] = await db.query("SELECT * FROM products WHERE category = ?", [category]);
      return { success: true, data: rows };
    } catch (error) {
      console.error("Error fetching products by category:", error.message);
      return { success: false, message: "Database error while fetching products by category", error };
    }
  }

  /**
   * Retrieve products within a price range.
   * @param {number} minPrice - Minimum price.
   * @param {number} maxPrice - Maximum price.
   * @returns {Promise<Object>} Object with success and data properties.
   */
  static async getProductsByPrice(minPrice, maxPrice) {
    try {
      const [rows] = await db.query(
        "SELECT * FROM products WHERE price BETWEEN ? AND ?",
        [minPrice, maxPrice]
      );
      return { success: true, data: rows };
    } catch (error) {
      console.error("Error fetching products by price:", error.message);
      return { success: false, message: "Database error while fetching products by price", error };
    }
  }

  /**
   * Create a new product.
   * @param {Object} productData - Product data.
   * @param {string} productData.name - Product name.
   * @param {string} productData.description - Product description.
   * @param {number} productData.price - Product price.
   * @param {string} productData.image - Product image URL.
   * @param {string} productData.category - Product category.
   * @returns {Promise<Object>} Object with success and data properties.
   */
  static async createProduct({ name, description, price, image, category }) {
    try {
      const result = await db.query(
        "INSERT INTO products (name, description, price, image, category) VALUES (?, ?, ?, ?, ?)",
        [name, description, price, image, category]
      );
      if (result.affectedRows > 0) {
        return { success: true, message: "Product created successfully", data: result };
      } else {
        return { success: false, message: "Failed to create product", data: null };
      }
    } catch (error) {
      console.error("Error creating product:", error.message);
      return { success: false, message: "Database error while creating product", error };
    }
  }

  /**
   * Update an existing product.
   * @param {number} id - Product ID.
   * @param {Object} updateData - Data to update.
   * @param {string} [updateData.name] - New product name.
   * @param {string} [updateData.description] - New description.
   * @param {number} [updateData.price] - New price.
   * @param {string} [updateData.image] - New image URL.
   * @param {string} [updateData.category] - New category.
   * @returns {Promise<Object>} Object with success and data properties.
   */
  static async updateProduct(id, { name, description, price, image, category }) {
    try {
      // Build the update query dynamically based on provided fields
      let query = "UPDATE products SET ";
      const params = [];
      if (name !== undefined) {
        query += "name = ?, ";
        params.push(name);
      }
      if (description !== undefined) {
        query += "description = ?, ";
        params.push(description);
      }
      if (price !== undefined) {
        query += "price = ?, ";
        params.push(price);
      }
      if (image !== undefined) {
        query += "image = ?, ";
        params.push(image);
      }
      if (category !== undefined) {
        query += "category = ?, ";
        params.push(category);
      }
      // Remove the trailing comma and space, then add WHERE clause.
      query = query.slice(0, -2) + " WHERE id = ?";
      params.push(id);

      const result = await db.query(query, params);
      if (result.affectedRows > 0) {
        return { success: true, message: "Product updated successfully", data: result };
      } else {
        return { success: false, message: "Product update failed", data: null };
      }
    } catch (error) {
      console.error("Error updating product:", error.message);
      return { success: false, message: "Database error while updating product", error };
    }
  }

  /**
   * Delete a product by its ID.
   * @param {number} id - Product ID.
   * @returns {Promise<Object>} Object with success and data properties.
   */
  static async deleteProduct(id) {
    try {
      const result = await db.query("DELETE FROM products WHERE id = ?", [id]);
      if (result.affectedRows > 0) {
        return { success: true, message: "Product deleted successfully", data: result };
      } else {
        return { success: false, message: "Product deletion failed", data: null };
      }
    } catch (error) {
      console.error("Error deleting product:", error.message);
      return { success: false, message: "Database error while deleting product", error };
    }
  }
}

module.exports = Product;
